// tests/eventRequest.submit.test.js
//
// Integration tests for "Creating Event Request" — entering the required
// details and submitting a draft for planning. Builds on the draft-save
// endpoints covered in eventRequest.draft.test.js; this file focuses on
// the submit action and its validation.

const request = require('supertest');
const app = require('../src/app');
const { sequelize } = require('../src/models');

const PASSWORD = 'Passw0rd1';

async function registerAndLogin(email) {
  await request(app).post('/api/auth/register').send({
    email,
    password: PASSWORD,
    firstName: 'Jane',
    lastName: 'Tan',
    role: 'event_organiser',
  });

  const res = await request(app).post('/api/auth/login').send({ email, password: PASSWORD });
  return res.body.accessToken;
}

describe('Creating Event Request', () => {
  const suffix = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  let organiserAToken;
  let organiserBToken;

  beforeAll(async () => {
    organiserAToken = await registerAndLogin(`submit-organiser-a-${suffix}@example.com`);
    organiserBToken = await registerAndLogin(`submit-organiser-b-${suffix}@example.com`);
  });

  afterAll(async () => {
    await sequelize.close();
  });

  test('can enter event name, preferred date/time, guest count, venue and equipment requirements', async () => {
    const res = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({
        eventName: 'Tech Conference 2026',
        preferredStart: '2026-11-10T09:00:00Z',
        preferredEnd: '2026-11-10T17:00:00Z',
        expectedAttendance: 150,
        venueRequirements: 'Large hall with stage',
        equipmentRequirements: 'Projector, microphones',
      });

    expect(res.status).toBe(201);
    expect(res.body.eventRequest).toMatchObject({
      eventName: 'Tech Conference 2026',
      expectedAttendance: 150,
      venueRequirements: 'Large hall with stage',
      equipmentRequirements: 'Projector, microphones',
    });
  });

  test('cannot enter an invalid number of guests (zero or negative)', async () => {
    const zeroRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({ eventName: 'Bad guest count', expectedAttendance: 0 });
    expect(zeroRes.status).toBe(400);

    const negativeRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({ eventName: 'Bad guest count', expectedAttendance: -5 });
    expect(negativeRes.status).toBe(400);
  });

  test('can submit the completed event request for planning', async () => {
    const createRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({
        eventName: 'Complete Request',
        preferredStart: '2026-12-01T09:00:00Z',
        preferredEnd: '2026-12-01T12:00:00Z',
        expectedAttendance: 40,
      });
    const id = createRes.body.eventRequest.id;

    const submitRes = await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send();

    expect(submitRes.status).toBe(200);
    expect(submitRes.body.eventRequest.status).toBe('submitted');
    expect(submitRes.body.eventRequest.submittedAt).not.toBeNull();
  });

  test('the submitted event request is saved and retrievable afterward', async () => {
    const createRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({
        eventName: 'Retrievable Request',
        preferredStart: '2026-12-05T09:00:00Z',
        preferredEnd: '2026-12-05T12:00:00Z',
        expectedAttendance: 20,
      });
    const id = createRes.body.eventRequest.id;

    await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send();

    const getRes = await request(app)
      .get(`/api/event-requests/${id}`)
      .set('Authorization', `Bearer ${organiserAToken}`);

    expect(getRes.status).toBe(200);
    expect(getRes.body.eventRequest.status).toBe('submitted');
  });

  test('cannot submit if required information is missing', async () => {
    const createRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({ eventName: 'Incomplete Request' }); // no dates, no attendance
    const id = createRes.body.eventRequest.id;

    const submitRes = await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send();

    expect(submitRes.status).toBe(400);
    expect(submitRes.body.missingFields).toEqual(
      expect.arrayContaining(['preferredStart', 'preferredEnd', 'expectedAttendance'])
    );
  });

  test('cannot submit a request that is not owned by the caller', async () => {
    const createRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({
        eventName: "Someone else's request",
        preferredStart: '2026-12-10T09:00:00Z',
        preferredEnd: '2026-12-10T12:00:00Z',
        expectedAttendance: 10,
      });
    const id = createRes.body.eventRequest.id;

    const submitRes = await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserBToken}`)
      .send();

    expect(submitRes.status).toBe(403);
  });

  test('cannot submit an already-submitted request again', async () => {
    const createRes = await request(app)
      .post('/api/event-requests')
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send({
        eventName: 'Double submit attempt',
        preferredStart: '2026-12-15T09:00:00Z',
        preferredEnd: '2026-12-15T12:00:00Z',
        expectedAttendance: 5,
      });
    const id = createRes.body.eventRequest.id;

    await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send();

    const secondSubmit = await request(app)
      .post(`/api/event-requests/${id}/submit`)
      .set('Authorization', `Bearer ${organiserAToken}`)
      .send();

    expect(secondSubmit.status).toBe(409);
  });
});